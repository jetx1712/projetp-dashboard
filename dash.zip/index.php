<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Full Screen Section</title>
    <link href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body {
            background: black;
        }

        .full-screen-section {
            height: 100vh;
            width: 100%;
            display: flex;
            justify-content: center;
            align-items: center;
            position: relative;
            overflow: hidden;
            /* background: linear-gradient(0deg, rgba(239,107,35,0.835171568627451) 0%, rgba(34,178,76,0.8407738095238095) 100%); */
        }

        .full-screen-section::before {
            content: "";
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background-image: url('images/back.gif');
            background-size: cover;
            background-position: center;
            filter: blur(10px);
            z-index: 0;
        }


        .blocos-maiores-1 {
            height: 100vh;
            width: 100%;
            display: grid;
            align-items: stretch;
            align-content: center;
            justify-items: center;
            justify-content: start;
        }

        .blocos-maiores-2 {
            height: 100vh;
            width: 100%;
            display: grid;
            align-items: stretch;
            align-content: center;
            justify-items: center;
            justify-content: end;
        }

        .blocos-maiores {
            height: 100vh;
            width: 100%;
            display: grid;
            align-items: stretch;
            align-content: center;
            justify-items: center;
            justify-content: center;
            margin-top: -60px;
        }

        .grafico {
            background: #000000a8;
            padding: 0px 10px 0px 10px;
            margin-top: 15px;
            border-radius: 10px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2), 0 6px 20px rgba(0, 0, 0, 0.19);
            display: flex;
            align-items: center;
            justify-content: center;
        }

        #clock {
            color: white;
            font-size: 20px;
            padding: 0px;
            letter-spacing: 3px;
        }

        .canvas-maior {
            width: 300px !important;
            height: 20vh !important;
        }

        .canvas-menor {
            width: 300px !important;
            height: 20vh !important;
        }
    </style>
</head>

<body>

    <section class="full-screen-section">
        <div style="display: flex;" class="col-md-12">
            <div class="col-md-4 blocos-maiores-1">
                <div class="grafico">
                    <canvas class="canvas-maior" id="chart1"></canvas>
                </div>
                <div class="grafico">
                    <canvas class="canvas-maior" id="chart2"></canvas>
                </div>
                <div class="grafico">
                    <canvas class="canvas-menor" id="chart3"></canvas>
                </div>
            </div>
            <div class="col-md-4 blocos-maiores">
                <div class="grafico">
                    <img style="max-width: 70%;" src="images/logo_final.gif" />
                </div>
                <div class="grafico">
                    <video style="max-width: 150%" muted loop autoplay src="images/video.mp4"></video>
                </div>
                <div class="grafico">
                    <div class="clock" id="clock"></div>
                </div>
            </div>
            <div class="col-md-4 blocos-maiores-2">
                <div class="grafico">
                    <canvas class="canvas-menor" id="chart4"></canvas>
                </div>
                <div class="grafico">
                    <canvas class="canvas-menor" id="chart5"></canvas>
                </div>
                <div class="grafico">
                    <canvas class="canvas-menor" id="chart6"></canvas>
                </div>
            </div>
        </div>
        <div style="position: absolute; bottom: 0px; width: 100vw;" class="col-md-12">
            <div style="width: 100%" class="card-body" id="logo-cnn">
                <rssapp-ticker id="JdRv4f8C7Sy9VA7c"></rssapp-ticker>
                <script src="https://widget.rss.app/v1/ticker.js" type="text/javascript" async></script>
            </div>
        </div>
    </section>

    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.3/dist/umd/popper.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <script>
        // Função para atualizar o relógio
        function updateClock() {
            const clockElement = document.getElementById('clock');
            const now = new Date();
            const hours = String(now.getUTCHours() - 3).padStart(2, '0'); // UTC-3 para Brasília
            const minutes = String(now.getMinutes()).padStart(2, '0');
            const seconds = String(now.getSeconds()).padStart(2, '0');
            clockElement.textContent = `${hours}:${minutes}:${seconds}`;
        }

        // Atualiza o relógio a cada segundo
        setInterval(updateClock, 1000);

        // Atualiza o relógio imediatamente após carregar a página
        updateClock();

        // Configurações dos gráficos
        var ctx1 = document.getElementById('chart1').getContext('2d');
        var chart1 = new Chart(ctx1, {
            type: 'bar',
            data: {
                labels: ['Vermelho', 'Azul', 'Amarelo', 'Verde', 'Roxo', 'Laranja'],
                datasets: [{
                    label: 'Exemplo 1',
                    data: [12, 19, 3, 5, 2, 3],
                    backgroundColor: [
                        'rgba(255, 99, 132, 0.2)',
                        'rgba(54, 162, 235, 0.2)',
                        'rgba(255, 206, 86, 0.2)',
                        'rgba(75, 192, 192, 0.2)',
                        'rgba(153, 102, 255, 0.2)',
                        '#ef6b23'
                    ],
                    borderColor: [
                        'rgba(255, 99, 132, 1)',
                        'rgba(54, 162, 235, 1)',
                        'rgba(255, 206, 86, 1)',
                        'rgba(75, 192, 192, 1)',
                        'rgba(153, 102, 255, 1)',
                        'rgba(255, 159, 64, 1)'
                    ],
                    borderWidth: 1
                }]
            },
            options: {
                scales: {
                    y: {
                        beginAtZero: true,
                        ticks: {
                            color: 'white' // cor dos labels do eixo Y
                        }
                    },
                    x: {
                        ticks: {
                            color: 'white' // cor dos labels do eixo X
                        }
                    }
                },
                plugins: {
                    legend: {
                        labels: {
                            color: 'white' // cor dos labels da legenda
                        }
                    }
                }
            }
        });

        var ctx2 = document.getElementById('chart2').getContext('2d');
        var chart2 = new Chart(ctx2, {
            type: 'line',
            data: {
                labels: ['Jan', 'Fev', 'Mar', 'Abr', 'Mai', 'Jun', 'Jul'],
                datasets: [{
                    label: 'Exemplo',
                    data: [65, 59, 80, 81, 56, 55, 40],
                    fill: false,
                    borderColor: 'rgb(75, 192, 192)',
                    tension: 0.1
                }]
            },
            options: {
                scales: {
                    y: {
                        beginAtZero: true,
                        ticks: {
                            color: 'white' // cor dos labels do eixo Y
                        }
                    },
                    x: {
                        ticks: {
                            color: 'white' // cor dos labels do eixo X
                        }
                    }
                },
                plugins: {
                    legend: {
                        labels: {
                            color: 'white' // cor dos labels da legenda
                        }
                    }
                }
            }
        });

        var ctx3 = document.getElementById('chart3').getContext('2d');
        var chart3 = new Chart(ctx3, {
            type: 'pie',
            data: {
                labels: ['Vermelho', 'Azul', 'Amarelo'],
                datasets: [{
                    label: 'gráfico',
                    data: [300, 50, 100],
                    backgroundColor: [
                        'rgb(255, 99, 132)',
                        'rgb(54, 162, 235)',
                        'rgb(255, 205, 86)'
                    ],
                    hoverOffset: 4
                }]
            },
            options: {
                scales: {
                    y: {
                        beginAtZero: true,
                        ticks: {
                            color: 'white' // cor dos labels do eixo Y
                        }
                    },
                    x: {
                        ticks: {
                            color: 'white' // cor dos labels do eixo X
                        }
                    }
                },
                plugins: {
                    legend: {
                        labels: {
                            color: 'white' // cor dos labels da legenda
                        }
                    }
                }
            }
        });

        var ctx4 = document.getElementById('chart4').getContext('2d');
        var chart4 = new Chart(ctx4, {
            type: 'doughnut',
            data: {
                labels: ['titu', 'titu', 'titu', 'titu'],
                datasets: [{
                    label: 'Exemplo 4',
                    data: [120, 150, 100, 170],
                    backgroundColor: [
                        'rgb(255, 99, 132)',
                        'rgb(54, 162, 235)',
                        'rgb(255, 205, 86)',
                        'rgb(75, 192, 192)'
                    ],
                    hoverOffset: 4
                }]
            },
            options: {
                scales: {
                    y: {
                        beginAtZero: true,
                        ticks: {
                            color: 'white' // cor dos labels do eixo Y
                        }
                    },
                    x: {
                        ticks: {
                            color: 'white' // cor dos labels do eixo X
                        }
                    }
                },
                plugins: {
                    legend: {
                        labels: {
                            color: 'white' // cor dos labels da legenda
                        }
                    }
                }
            }
        });

        var ctx5 = document.getElementById('chart5').getContext('2d');
        var chart5 = new Chart(ctx5, {
            type: 'radar',
            data: {
                labels: ['ex', 'ex', 'ex', 'ex', 'ex', 'ex', 'ex'],
                datasets: [{
                    label: 'Radar',
                    data: [65, 59, 90, 81, 56, 55, 40],
                    fill: true,
                    backgroundColor: 'rgba(255, 99, 132, 0.2)',
                    borderColor: 'rgb(255, 99, 132)',
                    pointBackgroundColor: 'rgb(255, 99, 132)',
                    pointBorderColor: '#fff',
                    pointHoverBackgroundColor: '#fff',
                    pointHoverBorderColor: 'rgb(255, 99, 132)'
                }, {
                    label: 'Radar comparativo',
                    data: [28, 48, 40, 19, 96, 27, 100],
                    fill: true,
                    backgroundColor: 'rgba(54, 162, 235, 0.2)',
                    borderColor: 'rgb(54, 162, 235)',
                    pointBackgroundColor: 'rgb(54, 162, 235)',
                    pointBorderColor: '#fff',
                    pointHoverBackgroundColor: '#fff',
                    pointHoverBorderColor: 'rgb(54, 162, 235)'
                }]
            },
            options: {
                elements: {
                    line: {
                        borderWidth: 3
                    }
                },
                scales: {
                    y: {
                        beginAtZero: true,
                        ticks: {
                            color: 'white' // cor dos labels do eixo Y
                        }
                    },
                    x: {
                        ticks: {
                            color: 'white' // cor dos labels do eixo X
                        }
                    }
                },
                plugins: {
                    legend: {
                        labels: {
                            color: 'white' // cor dos labels da legenda
                        }
                    }
                }
            }
        });

        var ctx6 = document.getElementById('chart6').getContext('2d');
        var chart6 = new Chart(ctx6, {
            type: 'polarArea',
            data: {
                labels: ['Vermelho', 'Verde', 'Amarelo', 'Grey', 'Azul'],
                datasets: [{
                    label: 'My First Dataset',
                    data: [11, 16, 7, 3, 14],
                    backgroundColor: [
                        'rgb(255, 99, 132)',
                        'rgb(75, 192, 192)',
                        'rgb(255, 205, 86)',
                        'rgb(201, 203, 207)',
                        'rgb(54, 162, 235)'
                    ]
                }]
            },
            options: {
                scales: {
                    y: {
                        beginAtZero: true,
                        ticks: {
                            color: 'white' // cor dos labels do eixo Y
                        }
                    },
                    x: {
                        ticks: {
                            color: 'white' // cor dos labels do eixo X
                        }
                    }
                },
                plugins: {
                    legend: {
                        labels: {
                            color: 'white' // cor dos labels da legenda
                        }
                    }
                }
            }
        });

        var ctx7 = document.getElementById('chart7').getContext('2d');
        var chart7 = new Chart(ctx7, {
            type: 'bar',
            data: {
                labels: ['Jan', 'Fev', 'Mar', 'Abr', 'Mai', 'Jun'],
                datasets: [{
                    label: 'Energia',
                    data: [12, 19, 3, 5, 2, 3],
                    backgroundColor: 'rgba(153, 102, 255, 0.2)',
                    borderColor: 'rgba(153, 102, 255, 1)',
                    borderWidth: 1
                }]
            },
            options: {
                scales: {
                    y: {
                        beginAtZero: true,
                        ticks: {
                            color: 'white'
                        }
                    },
                    x: {
                        ticks: {
                            color: 'white'
                        }
                    }
                },
                plugins: {
                    legend: {
                        labels: {
                            color: 'white'
                        }
                    }
                }
            }
        });

        var ctx8 = document.getElementById('chart8').getContext('2d');
        var chart8 = new Chart(ctx8, {
            type: 'line',
            data: {
                labels: ['Q1', 'Q2', 'Q3', 'Q4'],
                datasets: [{
                    label: 'C02',
                    data: [65, 59, 80, 81],
                    fill: false,
                    borderColor: 'rgba(255, 159, 64, 1)',
                    tension: 0.1
                }]
            },
            options: {
                scales: {
                    y: {
                        beginAtZero: true,
                        ticks: {
                            color: 'white'
                        }
                    },
                    x: {
                        ticks: {
                            color: 'white'
                        }
                    }
                },
                plugins: {
                    legend: {
                        labels: {
                            color: 'white'
                        }
                    }
                }
            }
        });

        var ctx9 = document.getElementById('chart9').getContext('2d');
        var chart9 = new Chart(ctx9, {
            type: 'doughnut',
            data: {
                labels: ['A', 'B', 'C', 'D'],
                datasets: [{
                    label: 'Categorias',
                    data: [120, 90, 70, 30],
                    backgroundColor: [
                        'rgba(255, 99, 132, 0.2)',
                        'rgba(54, 162, 235, 0.2)',
                        'rgba(255, 206, 86, 0.2)',
                        'rgba(75, 192, 192, 0.2)'
                    ],
                    borderColor: [
                        'rgba(255, 99, 132, 1)',
                        'rgba(54, 162, 235, 1)',
                        'rgba(255, 206, 86, 1)',
                        'rgba(75, 192, 192, 1)'
                    ],
                    borderWidth: 1
                }]
            },
            options: {
                scales: {
                    y: {
                        beginAtZero: true,
                        ticks: {
                            color: 'white'
                        }
                    },
                    x: {
                        ticks: {
                            color: 'white'
                        }
                    }
                },
                plugins: {
                    legend: {
                        labels: {
                            color: 'white'
                        }
                    }
                }
            }
        });
    </script>
</body>

</html>